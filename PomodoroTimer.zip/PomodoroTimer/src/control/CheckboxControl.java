package control;

import javax.swing.*;

public class CheckboxControl extends JPanel {
    protected JCheckBox Date_cb = new JCheckBox("Date");
    protected JCheckBox CurrentTime_cb = new JCheckBox("Current Time");
}

